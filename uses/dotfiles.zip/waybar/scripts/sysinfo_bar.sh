#!/bin/bash
echo "⚙"
